<?php
abstract class PaymentMethod{
    abstract public function payment(Transaction $transaction, $sale); 
}

class ABA extends PaymentMethod {
    public function payment(Transaction $transaction, $sale){
        $sale->addtosale($transaction); 
    }
}
class Wing extends PaymentMethod {
    public function payment(Transaction $transaction, $sale){
        $sale->addtosale($transaction); 
    }
}

class PiPay extends PaymentMethod {
    public function payment(Transaction $transaction, $sale){
        $sale->addtosale($transaction);  
    }
}