<?php

require("transactionInfo.php");
class SaleData {
    private $orderData = [];
    public function putInSale(Transaction $transaction){
        $this->orderData[] = $transaction; 
    }
    public function displayTransaction($method){
        $count = 0; 
        for($i = 0; $i < count($this->orderData); $i++){
            if($this->orderData[$i]->method() == $method){
                $count += 1;
            }
        }
        return $count; 
    }
    public function displayABA() {
        return $this->displayTransaction("ABA");
    }
    public function displayWingPiPay(){
        return $this->displayTransaction("Wing") + $this->displayTransaction("PiPay"); 
    }
    public function displayOrdering(){
        usort($this->orderData, function($a, $b) {
            if($a->getTotalOrder()==$b->getTotalOrder()) return 0;
            return $a->getTotalOrder() < $b->getTotalOrder()?1:-1;
        });
        echo "
        <table style=\"width:100%;border:1.5px solid black\">
        <tr >
        <th style=\"border:1.5px solid black\">Name</th>
        <th style=\"border:1.5px solid black\">Price</th> 
        <th style=\"border:1.5px solid black\">Quantity</th>
        <th style=\"border:1.5px solid black\">Method</th>
        <th style=\"border:1.5px solid black\">Total</th>
        </tr>"; 

        for($i = 0; $i < count($this->orderData); $i++){
            $this->orderData[$i]->displayInfo(); 
            echo "<br>" . "\n\n"; 
        }
    }
}

?>