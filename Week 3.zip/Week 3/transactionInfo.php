<?php

class Transaction {
    private $name; 
    private $price;
    private $quantity; 
    private $method; 
    private $totalOrder; 
    public function __construct($name, $price,$quantity,$method){
        $this->name = $name; 
        $this->price = $price;  
        $this->quantity = $quantity; 
        $this->method = $method;
        $this->totalOrder = $quantity*$price;
    }
    public function getTotalOrder(){
        return $this->totalOrder; 
    }
    public function method(){
        return $this->method; 
    }
    public function displayTraxInfo(){
        echo "<tr>
             <td style=\"border:1.5px solid black\">$this->name</td>
             <td style=\"border:1.5px solid black\">$this->price</td>
             <td style=\"border:1.5px solid black\">$this->quantity</td>
             <td style=\"border:1.5px solid black\">$this->method</td>
             <td style=\"border:1.5px solid black\">$this->totalOrder</td>
             </tr>"; 
    }
}

?>