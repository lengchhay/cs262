<!DOCTYPE html>
<html>
<body>

<?php
class Food {
  public $burger;
  public $flavor;
  public function __construct($burger, $flavor) {
    $this->burger = $burger;
    $this->flavor = $flavor; 
  }
  public function order() {
    echo "The Food is {$this->burger} and the flavor is {$this->flavor}."; 
  }
}

class ChickenBurger extends Food {
  public $price;
  public function __construct($burger, $flavor, $price) {
    $this->burger = $burger;
    $this->flavor = $flavor;
    $this->price = $price; 
  }
  public function order() {
    echo "The Food is {$this->burger}, the flavor is {$this->flavor}, and the price is {$this->price} USD."; 
  }
}

$ChickenBurger = new ChickenBurger("Chicken Burger", "spicy", 4.5);
$ChickenBurger->order();
?>
 
</body>
</html>


