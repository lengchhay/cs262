<?php

function sum(...$numbers) {
  $total = 0;
  foreach($numbers as $n) {
      $total+=$n; 
    }
  return $total;
}
  
echo ("Total: " .sum(2,3));
echo nl2br (".\nTotal: " .sum(2,3,4));
echo nl2br (".\nTotal: " .sum(2,3,4,5));

?>