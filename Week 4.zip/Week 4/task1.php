<?php

//call funtion for reversing  
function string($reverse) {

    $stringRev = strrev($reverse);              //revers string backward
    $splitStr = explode(" ", $stringRev);       //separate the text into array
    $result = "";                               //declare result as string
    $countStr = count($splitStr);               //count the length of the string
    
    //using for loop with the given array length to execute the result 
    for($i =$countStr - 1; $i >= 0; $i--) {
        $result = $result .  $splitStr[$i];
        $result = $result . " ";}

    return $result;                             //execute the variable
}
// assign a string 
echo string("emocleW ot PHP");                  //echo the string
?>
