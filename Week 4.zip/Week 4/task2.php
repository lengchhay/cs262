<?php

$arraynum = [2,3,4,6,7,9,11,20];

function even($num)
{
    return !($num & 1);
}

echo "Here is the even number :\n";
print_r(array_filter($arraynum, "even"));


?>